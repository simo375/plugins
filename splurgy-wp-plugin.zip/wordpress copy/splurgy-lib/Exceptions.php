<?php
class TokenErrorException extends Exception {}
class TemplateErrorException extends Exception {}
?>
